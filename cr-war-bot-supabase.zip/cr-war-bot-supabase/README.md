# CR War Bot — version Supabase (serverless)

- `discord` (Edge Function) : reçoit les commandes slash via « Interactions Endpoint URL ».
- `cron` (Edge Function) : appelée toutes les 5 min par `pg_cron` → rappels à pression progressive + rapports de fin de guerre.
- Postgres : clans, liens joueur ↔ Discord, paramètres, rappels déjà envoyés.

## Déploiement
Prérequis : compte Supabase (gratuit), projet créé, Node 20+.

1. Dans ce dossier : `npx supabase login` puis `npx supabase link --project-ref <PROJECT_REF>`
   (le Project ref est dans l'URL du dashboard, ou Settings → General).
2. **Base de données** : `npx supabase db push`
   (ou colle `supabase/migrations/001_init.sql` dans SQL Editor → Run).
3. **Secrets** :
   ```
   npx supabase secrets set DISCORD_TOKEN=... DISCORD_PUBLIC_KEY=... DISCORD_APP_ID=... CR_API_TOKEN=... CR_API_BASE=https://proxy.royaleapi.dev/v1 CRON_SECRET=une_longue_phrase_secrete
   ```
   - `DISCORD_PUBLIC_KEY` et `DISCORD_APP_ID` : portail Discord → ton appli → General Information.
   - Les Edge Functions n'ont pas d'IP fixe : garde le proxy RoyaleAPI et la clé Clash Royale créée avec l'IP `45.79.218.79`.
4. **Fonctions** : `npx supabase functions deploy discord` puis `npx supabase functions deploy cron`
5. **Discord** : portail développeur → General Information → **Interactions Endpoint URL** =
   `https://<PROJECT_REF>.supabase.co/functions/v1/discord` → Save (Discord envoie un test de signature).
6. **Commandes** : copie `.env.example` en `.env`, remplis-le, puis
   `node --env-file=.env scripts/register-commands.mjs`
7. **Planification** : ouvre `supabase/schedule.sql`, remplace `<PROJECT_REF>` et `<CRON_SECRET>`, exécute-le dans SQL Editor.
8. **Arrête l'ancien bot Node** (inutile maintenant) et ajoute les clans avec `/clan ajouter`.

## Dépannage
- « Impossible de vérifier l'URL » à l'étape 5 : mauvaise `DISCORD_PUBLIC_KEY`, ou fonction non déployée.
- Logs : dashboard Supabase → Edge Functions → discord / cron → Logs.
- Vérifier le cron : `select * from cron.job_run_details order by start_time desc limit 10;`
- Les anciennes données (`data/db.json`) ne sont pas migrées : refais `/clan ajouter` et `/lier`.
